/**
 * adc_def.h - ADC 功能封装 (头文件)
 * by Nixsawe <ziming_cool@126.com>
 * 进行 ADC 相关资源的初始化与控制功能封装
 */

#ifndef _ADC_DEF_H_
#define _ADC_DEF_H_

// 包含必备头文件
#include<osal_debug.h>
#include<common_def.h>
#include<soc_osal.h>
#include<stdio.h>
#include<unistd.h>
#include<errcode.h>
#include<pinctrl.h>
#include<adc.h>
#include<adc_porting.h>

// 常量定义
#define ADC_LEFT_X_CHANNEL   1   // ADC1 - GPIO_08
#define ADC_LEFT_Y_CHANNEL   2   // ADC2 - GPIO_09
#define ADC_RIGHT_X_CHANNEL  0   // ADC0 - GPIO_07
#define ADC_RIGHT_Y_CHANNEL  3   // ADC3 - GPIO_10

// 函数原型
void adc_init(void);
int32_t adc_auto_sample(uint8_t channel, uint32_t delay_ticks);
void my_adc_callback_func(uint8_t channel, uint32_t * buffer, uint32_t length, bool * next);

#endif /* _ADC_DEF_H_ */

