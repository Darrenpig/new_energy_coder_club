/**
 * joystick.h - 摇杆功能封装 (头文件)
 * by Nixsawe <ziming_cool@126.com>
 * 摇杆控制功能计算及封装
 */

#ifndef _JOYSTICK_DEF_H_
#define _JOYSTICK_DEF_H_

#include<stdint.h>

// 类型定义
typedef struct {
    int32_t low, mid, high;
} joystick_range_t;

extern int32_t joystick_raw[4];
extern int32_t joystick_processed[4];
extern joystick_range_t joystick_ranges[4];

// 常量定义
#define JOYSTICK_LEFT_X     0
#define JOYSTICK_LEFT_Y     1
#define JOYSTICK_RIGHT_X    2
#define JOYSTICK_RIGHT_Y    3

// 函数原型
int joystick_calibrate(void);
void joystick_process(void);

#endif /* _JOYSTICK_DEF_H_ */

