/**
 * main.h - 主文件 (头文件)
 * by Nixsawe <ziming_cool@126.com>
 * 手柄主程序
 */

#ifndef _MAIN_H_
#define _MAIN_H_

// 包含必备头文件
#include<osal_debug.h>
#include<common_def.h>
#include<soc_osal.h>
#include<app_init.h>
#include "gpio_def.h"
#include "sle_def.h"
#include "adc_def.h"
#include "joystick_def.h"

// 常量定义

// 函数原型
int joystick_init(void);
int JoystickMain(void * arg);
int JoystickScanThread(void * arg);
void JoystickRun(void);

#endif /* _MAIN_H_ */

