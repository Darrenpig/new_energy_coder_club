/**
 * main.c - 主文件
 * by Nixsawe <ziming_cool@126.com>
 * 手柄主程序，作为 SLE 的 Client 端
 */

#include "../inc/main.h"
int k1, k2, k1_last, k2_last;
// 执行客户端初始化
int joystick_init(void)
{
    // 初始化 GPIO
    gpio_init();
    // 初始化 ADC
    adc_init();
    return 1;
}
osal_task *task_scan = NULL;


// 手柄主线程
int JoystickMain(void * arg)
{
    (void)arg;
    // 等待一定时间，然后执行初始化
    osal_msleep(2000);
    joystick_init();
    // 上电后所有 LED 短暂亮一瞬间
    uapi_gpio_set_val(LED_A, 0);
    uapi_gpio_set_val(LED_B, 0);
    uapi_gpio_set_val(LED_STATE, 0);
    osal_msleep(500);
    uapi_gpio_set_val(LED_A, 1);
    uapi_gpio_set_val(LED_B, 1);
    uapi_gpio_set_val(LED_STATE, 1);
    osal_kthread_resume(task_scan);
    while(1)
    {
        k1 = uapi_gpio_get_val(KEY_MODE);
        k2 = uapi_gpio_get_val(KEY_SLE);
        if(k1==0 && k1_last==1)//当mode键被按下时
        {
            osal_printk("\r\n------------KEY_MODE------------\r\n\r\n");
        }
        if(k2==0 && k2_last==1)//当sle键被按下时
        {
            osal_printk("\r\n------------KEY_SLE------------\r\n\r\n");
        }
        k2_last=k2;
        k1_last=k1;

        //每100ms将双摇杆数据打印至串口
        osal_printk("left_x:%5d, left_y:%5d ; right_x:%5d, right_y:%5d\r\n", joystick_processed[0], joystick_processed[1], joystick_processed[2], joystick_processed[3]);
        osDelay(10);
    }
}



// 手柄摇杆扫描定时器
// 正常工作时 10ms 进行一次 ADC 采集
int JoystickScanThread(void * arg)
{
    (void)arg;
    while(1)
    {
        int32_t lx = adc_auto_sample(ADC_LEFT_X_CHANNEL, 0);
        int32_t rx = adc_auto_sample(ADC_RIGHT_X_CHANNEL, 0);
        int32_t ly = adc_auto_sample(ADC_LEFT_Y_CHANNEL, 0);
        int32_t ry = adc_auto_sample(ADC_RIGHT_Y_CHANNEL, 0);
        // 摇杆的 X Y 是反过来的
        joystick_raw[JOYSTICK_LEFT_X] = ly;
        joystick_raw[JOYSTICK_LEFT_Y] = lx;
        joystick_raw[JOYSTICK_RIGHT_X] = ry;
        joystick_raw[JOYSTICK_RIGHT_Y] = rx;
        // 更新摇杆值
        joystick_process();
        
        osal_msleep(10);
    }
}

// 不可恢复的错误指示，应该显示特定的 LED 效果
void JoystickFatalLoop(void)
{
    osal_printk("========== JoystickFatalLoop ==========\r\n");

    int flag_state = 0;
    int flag_a = 1;
    int flag_b = 0;
    int ctr = 0;
    while(true)
    {
        osal_printk("fatal_loop\r\n");
        if(++ ctr > 4)
        {
            ctr = 0;
            // 其他 LED 1000ms 秒交替一次
            uapi_gpio_set_val(LED_A, flag_a);
            uapi_gpio_set_val(LED_B, flag_b);
            flag_a = !flag_a;
            flag_b = !flag_b;
        }
        // SLE 状态灯 250ms 切换一次
        uapi_gpio_set_val(LED_STATE, flag_state);
        flag_state = !flag_state;
        osal_msleep(250);
    }
}

void JoystickRun(void)
{
    osal_kthread_lock();

    // 创建主线程
    if(NULL == osal_kthread_create(JoystickMain, NULL, "TaskMain", 0x1000))
    {
        osal_printk("Failed to create thread TaskMain (JoystickMain)!\r\n");
        JoystickFatalLoop();
        return;
    }
    // 创建摇杆状态采集线程
    task_scan = osal_kthread_create(JoystickScanThread, NULL, "TaskJs", 0x1000);
    if(task_scan == NULL)
    {
        osal_printk("Failed to create timer TaskJs (JoystickScanThread)!\r\n");
        JoystickFatalLoop();
        return;
    }
    osal_kthread_suspend(task_scan);

    osal_kthread_unlock();
}

app_run(JoystickRun);
