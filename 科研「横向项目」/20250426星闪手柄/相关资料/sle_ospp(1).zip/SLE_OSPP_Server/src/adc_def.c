/**
 * adc_def.c - ADC 功能封装
 * by Nixsawe <ziming_cool@126.com>
 * 进行 ADC 相关资源的初始化与控制功能封装
 */

#include "../inc/adc_def.h"

// ADC 自动采样配置参数 (实际上库里面压根没有用到这个结构体)
adc_scan_config_t adc_config_dummy = {
    .type = 0,          // FIFO全扫描或阈值扫描
    // .threshold_l = 0.5, // 阈值扫描电压（v）下限
    // .threshold_h = 4.9, // 阈值扫描电压（v）上限
    .freq = 1,          // ADC扫描频率，用于所有频道
};

// 初始化 ADC
void adc_init(void)
{
    // 使用 500kHz 时钟
    errcode_t result = uapi_adc_init(ADC_CLOCK_500KHZ);
    if(result != ERRCODE_SUCC)
    {
        osal_printk("Failed to init ADC, code: %08x\r\n", result);
        return;
    }
    // ADC 上电并配置为常规精度模式
    uapi_adc_power_en(AFE_GADC_MODE, true);
}

int32_t adc_sample_values[4];
int32_t adc_auto_sample(uint8_t channel, uint32_t delay_ticks)
{
    // 开启自动 ADC 采样
    adc_sample_values[channel] = -1;
    errcode_t result = uapi_adc_auto_scan_ch_enable(channel, adc_config_dummy, my_adc_callback_func);
    if(result != ERRCODE_SUCC)
    {
        osal_printk("Failed to start auto scan, code: %08x\r\n", result);
        return adc_sample_values[channel];
    }
    // 延时指定的时间
    if(delay_ticks)
    {
        osal_msleep(delay_ticks * 10);
    }
    // 关闭自动采样 (关闭后才会将之前采样的数据一股脑传给回调)
    uapi_adc_auto_scan_ch_disable(channel);
    return adc_sample_values[channel];
}

// ADC 回调函数
void my_adc_callback_func(uint8_t channel, uint32_t * buffer, uint32_t length, bool * next)
{
    if(length == 0 || channel >= (uint8_t)(sizeof(adc_sample_values) / sizeof(adc_sample_values[0]))) return;
    // for(uint32_t i = 0; i < length; i ++)
    // {
    //     osal_printk("ADC callback read#%hhd[%d]: %d\r\n", channel, i, buffer[i]);
    // }
    if(length < 2)
        adc_sample_values[channel] = (int32_t)(buffer[1]);
    else
        adc_sample_values[channel] = (int32_t)(buffer[1] ? buffer[1] : buffer[2]);
}
