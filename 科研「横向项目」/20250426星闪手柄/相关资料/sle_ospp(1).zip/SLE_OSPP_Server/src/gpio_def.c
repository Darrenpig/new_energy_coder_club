/**
 * gpio_def.c - GPIO 功能封装
 * by Nixsawe <ziming_cool@126.com>
 * 进行 GPIO 相关资源的初始化与控制功能封装
 */

#include "../inc/gpio_def.h"

// 初始化 GPIO
void gpio_init(void)
{
    // 初始化 pinctrl
    uapi_pin_init();

    // 设置引脚功能为 MODE_0(GPIO)
    // TODO: V100 版本 SDK 中，有其它地方会修改 GPIO_7 的 MODE。需要检查或者延迟
    //       好像那个是 ADC 引脚，不在这里初始化
    errcode_t ret;
    do
    {
        ret = uapi_pin_set_mode(LED_STATE, PIN_MODE_0); // GPIO_00 配网 LED 灯, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_pin_set_mode(KEY_MODE , PIN_MODE_0); // GPIO_01 MODE 按键, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_pin_set_mode(KEY_SLE  , PIN_MODE_0); // GPIO_02 SLE 按键, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_pin_set_mode(LED_A    , PIN_MODE_0); // GPIO_03 自定义 LED, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_pin_set_mode(KEY_LEFT , PIN_MODE_2); // GPIO_04 前左自定义按键, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_pin_set_mode(KEY_RIGHT, PIN_MODE_4); // GPIO_05 前右自定义按键, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_pin_set_mode(LED_B    , PIN_MODE_0); // GPIO_06 自定义 LED, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_pin_set_mode(SW_LEFT  , PIN_MODE_0); // GPIO_13 左摇杆 SW, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_pin_set_mode(SW_RIGHT , PIN_MODE_0); // GPIO_14 右摇杆 SW, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
    } while(false);
    if(ret != ERRCODE_SUCC)
    {
        osal_printk("uapi_pin_set_mode: some failed, code: %08x\r\n", ret);
    }

    // 设置 GPIO 方向
    do
    {
        ret = uapi_gpio_set_dir(LED_STATE, GPIO_DIRECTION_OUTPUT);    // GPIO_00 配网 LED 灯, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_gpio_set_dir(KEY_MODE , GPIO_DIRECTION_INPUT);     // GPIO_01 MODE 按键, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_gpio_set_dir(KEY_SLE  , GPIO_DIRECTION_INPUT);     // GPIO_02 SLE 按键, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_gpio_set_dir(LED_A    , GPIO_DIRECTION_OUTPUT);    // GPIO_03 自定义 LED, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_gpio_set_dir(KEY_LEFT , GPIO_DIRECTION_INPUT);     // GPIO_04 前左自定义按键, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_gpio_set_dir(KEY_RIGHT, GPIO_DIRECTION_INPUT);     // GPIO_05 前右自定义按键, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_gpio_set_dir(LED_B    , GPIO_DIRECTION_OUTPUT);    // GPIO_06 自定义 LED, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_gpio_set_dir(SW_LEFT  , GPIO_DIRECTION_INPUT);     // GPIO_13 左摇杆 SW, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_gpio_set_dir(SW_RIGHT , GPIO_DIRECTION_INPUT);     // GPIO_14 右摇杆 SW, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
    } while(false);
    if(ret != ERRCODE_SUCC)
    {
        osal_printk("uapi_gpio_set_dir: some failed, code: %08x\r\n", ret);
    }

    // 配置上拉/下拉
    do
    {
        ret = uapi_pin_set_pull(KEY_MODE , PIN_PULL_TYPE_UP);     // GPIO_01 MODE 按键, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_pin_set_pull(KEY_SLE  , PIN_PULL_TYPE_UP);     // GPIO_02 SLE 按键, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_pin_set_pull(KEY_LEFT , PIN_PULL_TYPE_UP);     // GPIO_04 前左自定义按键, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_pin_set_pull(KEY_RIGHT, PIN_PULL_TYPE_UP);     // GPIO_05 前右自定义按键, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_pin_set_pull(SW_LEFT  , PIN_PULL_TYPE_UP);     // GPIO_13 左摇杆 SW, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_pin_set_pull(SW_RIGHT , PIN_PULL_TYPE_UP);     // GPIO_14 右摇杆 SW, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
    } while(false);
    if(ret != ERRCODE_SUCC)
    {
        osal_printk("uapi_pin_set_pull: some failed, code: %08x\r\n", ret);
    }

    // 配置 GPIO 引脚默认电平
    do
    {
        ret = uapi_gpio_set_val(LED_STATE, GPIO_LEVEL_HIGH);      // GPIO_00 配网 LED 灯, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_gpio_set_val(LED_A, GPIO_LEVEL_HIGH);          // GPIO_03 自定义 LED, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
        ret = uapi_gpio_set_val(LED_B, GPIO_LEVEL_HIGH);          // GPIO_06 自定义 LED, GPIO 模式
        if(ret != ERRCODE_SUCC) break;
    } while(false);
    if(ret != ERRCODE_SUCC)
    {
        osal_printk("uapi_gpio_set_val: some failed, code: %08x\r\n", ret);
    }
}
