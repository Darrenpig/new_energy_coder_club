/**
 * sle_def.c - SLE 功能封装
 * by Nixsawe <ziming_cool@126.com>
 * 进行 SLE 相关资源的初始化与控制功能封装
 */

#include "../inc/sle_def.h"

static char g_sle_uuid_app_uuid[] = { 0x39, 0xBE, 0xA8, 0x80, 0xFC, 0x70, 0x11, 0xEA, \
    0xB7, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
static ssapc_find_service_result_t g_sle_uart_find_service_result = { 0 };
static sle_announce_seek_callbacks_t g_sle_uart_seek_cbk = { 0 };
static sle_connection_callbacks_t g_sle_uart_connect_cbk = { 0 };
static ssapc_callbacks_t g_sle_uart_ssapc_cbk = { 0 };
static sle_addr_t g_sle_uart_remote_addr = { 0 };
ssapc_write_param_t g_sle_uart_send_param = { 0 };
uint16_t g_sle_uart_conn_id = 0;
uint8_t g_client_id = 0;

uint8_t sle_connected = 0;

// 开启 SLE 设备发现
void sle_uart_start_scan(void)
{
    sle_seek_param_t param = { 0 };
    param.own_addr_type = 0;
    param.filter_duplicates = 0;
    param.seek_filter_policy = 0;
    param.seek_phys = 1;
    param.seek_type[0] = 1;
    param.seek_interval[0] = SLE_SEEK_INTERVAL_DEFAULT;
    param.seek_window[0] = SLE_SEEK_WINDOW_DEFAULT;
    sle_set_seek_param(&param);
    sle_start_seek();
}

// SLE 使能回调函数
static void my_sle_enable_cbk(errcode_t status)
{
    if(status != 0)
    {
        osal_printk("%s my_sle_enable_cbk, status error\r\n", SLE_UART_CLIENT_LOG);
    }
    else
    {
        osal_msleep(1000);
        sle_uart_start_scan();
    }
}

// 设备发现使能回调函数
static void my_seek_enable_cbk(errcode_t status)
{
    if(status != 0)
    {
        osal_printk("%s my_seek_enable_cbk, status error\r\n", SLE_UART_CLIENT_LOG);
    }
}

// 设备发现结果上报回调函数
static void my_seek_result_info_cbk(sle_seek_result_info_t *seek_result_data)
{
    osal_printk("%s sle uart scan data: %s\r\n", SLE_UART_CLIENT_LOG, seek_result_data -> data);
    if(seek_result_data == NULL)
    {
        osal_printk("status error\r\n");
    }
    else if(strstr((const char *)seek_result_data -> data, SLE_UART_SERVER_NAME) != NULL)
    {
        memcpy_s(&g_sle_uart_remote_addr, sizeof(sle_addr_t), &seek_result_data->addr, sizeof(sle_addr_t));
        sle_stop_seek();
    }
}

// 设备发现停用回调函数
static void my_seek_disable_cbk(errcode_t status)
{
    if(status != 0)
    {
        osal_printk("%s my_seek_disable_cbk, status error\r\n", SLE_UART_CLIENT_LOG);
    }
    else
    {
       sle_connect_remote_device(&g_sle_uart_remote_addr);
    }
}

// 注册设备发现事件回调
static void sle_seek_cbk_register(void)
{
    g_sle_uart_seek_cbk.sle_enable_cb   = my_sle_enable_cbk;
    g_sle_uart_seek_cbk.seek_enable_cb  = my_seek_enable_cbk;
    g_sle_uart_seek_cbk.seek_result_cb  = my_seek_result_info_cbk;
    g_sle_uart_seek_cbk.seek_disable_cb = my_seek_disable_cbk;
    sle_announce_seek_register_callbacks(&g_sle_uart_seek_cbk);
}

// 连接状态变更回调函数
static void my_connect_state_changed_cbk(uint16_t conn_id, const sle_addr_t *addr,
    sle_acb_state_t conn_state, sle_pair_state_t pair_state, sle_disc_reason_t disc_reason)
{
    (void)addr;
    (void)pair_state;
    osal_printk("%s conn state changed disc_reason: 0x%x\r\n", SLE_UART_CLIENT_LOG, disc_reason);
    g_sle_uart_conn_id = conn_id;
    if(conn_state == SLE_ACB_STATE_CONNECTED)
    {
        sle_connected = 1;
        osal_printk("%s SLE_ACB_STATE_CONNECTED\r\n", SLE_UART_CLIENT_LOG);
        ssap_exchange_info_t info = {0};
        info.mtu_size = SLE_MTU_SIZE_DEFAULT;
        info.version = 1;
        ssapc_exchange_info_req(0, conn_id, &info);
    }
    else if(conn_state == SLE_ACB_STATE_NONE)
    {
        sle_connected = 0;
        osal_printk("%s SLE_ACB_STATE_NONE\r\n", SLE_UART_CLIENT_LOG);
    }
    else if(conn_state == SLE_ACB_STATE_DISCONNECTED)
    {
        sle_connected = 0;
        osal_printk("%s SLE_ACB_STATE_DISCONNECTED\r\n", SLE_UART_CLIENT_LOG);
        sle_uart_start_scan();
    }
    else
    {
        osal_printk("%s status error\r\n", SLE_UART_CLIENT_LOG);
    }
}

// 注册连接事件回调
static void sle_connect_cbk_register(void)
{
    g_sle_uart_connect_cbk.connect_state_changed_cb = my_connect_state_changed_cbk;
    sle_connection_register_callbacks(&g_sle_uart_connect_cbk);
}

// 信息交换回调函数
static void my_exchange_info_cbk(uint8_t client_id, uint16_t conn_id, ssap_exchange_info_t *param,
                                                     errcode_t status)
{
    osal_printk("%s exchange_info_cbk, pair complete client id: %d status: %d\r\n",
                SLE_UART_CLIENT_LOG, client_id, status);
    osal_printk("%s exchange mtu, mtu size: %d, version: %d.\r\n", SLE_UART_CLIENT_LOG,
                param -> mtu_size, param -> version);
    ssapc_find_structure_param_t find_param = { 0 };
    find_param.type = 1;
    find_param.start_hdl = 1;
    find_param.end_hdl = 0xFFFF;
    int ret = ssapc_find_structure(client_id, conn_id, &find_param);
    osal_printk("ssapc_find_structure_errcode: %d\r\n", ret);
}

// 服务结构搜索回调函数
static void my_find_structure_cbk(uint8_t client_id, uint16_t conn_id,
                                                      ssapc_find_service_result_t *service,
                                                      errcode_t status)
{
    osal_printk("%s find structure cbk client: %d conn_id: %d status: %d \r\n", SLE_UART_CLIENT_LOG,
                client_id, conn_id, status);
    osal_printk("%s find structure start_hdl:[0x%02x], end_hdl:[0x%02x], uuid len: %d\r\n", SLE_UART_CLIENT_LOG,
                service -> start_hdl, service -> end_hdl, service -> uuid.len);
    g_sle_uart_find_service_result.start_hdl = service -> start_hdl;
    g_sle_uart_find_service_result.end_hdl = service -> end_hdl;
    memcpy_s(&g_sle_uart_find_service_result.uuid, sizeof(sle_uuid_t), &service -> uuid, sizeof(sle_uuid_t));
}

// 服务属性搜索回调函数
static void my_find_property_cbk(uint8_t client_id, uint16_t conn_id,
                                                     ssapc_find_property_result_t *property,
                                                     errcode_t status)
{
    osal_printk("%s my_find_property_cbk, client id: %d, conn id: %d, operate ind: %d, "
                "descriptors count: %d status:%d property->handle %d\r\n", SLE_UART_CLIENT_LOG,
                client_id, conn_id, property->operate_indication,
                property->descriptors_count, status, property->handle);
    g_sle_uart_send_param.handle = property->handle;
    g_sle_uart_send_param.type = SSAP_PROPERTY_TYPE_VALUE;
}

// 服务结构搜索完毕回调函数
static void my_find_structure_cmp_cbk(uint8_t client_id, uint16_t conn_id,
                                                          ssapc_find_structure_result_t *structure_result,
                                                          errcode_t status)
{
    (void)conn_id;
    osal_printk("%s my_find_structure_cmp_cbk, client id: %d status: %d type: %d uuid len: %d \r\n",
                SLE_UART_CLIENT_LOG, client_id, status, structure_result -> type, structure_result -> uuid.len);
}

// 收到写响应回调函数
static void my_write_cfm_cb(uint8_t client_id, uint16_t conn_id,
                                                ssapc_write_result_t *write_result, errcode_t status)
{
    osal_printk("%s my_write_cfm_cb, conn_id: %d client id: %d status: %d handle: %02x type: %02x\r\n",
                SLE_UART_CLIENT_LOG, conn_id, client_id, status, write_result -> handle, write_result -> type);
}

// 注册 SLE SSAP 客户端事件回调
static void sle_ssapc_cbk_register(ssapc_notification_callback notification_cb,
                                                      ssapc_indication_callback indication_cb)
{
    g_sle_uart_ssapc_cbk.exchange_info_cb        = my_exchange_info_cbk;
    g_sle_uart_ssapc_cbk.find_structure_cb       = my_find_structure_cbk;
    g_sle_uart_ssapc_cbk.ssapc_find_property_cbk = my_find_property_cbk;
    g_sle_uart_ssapc_cbk.find_structure_cmp_cb   = my_find_structure_cmp_cbk;
    g_sle_uart_ssapc_cbk.write_cfm_cb            = my_write_cfm_cb;
    g_sle_uart_ssapc_cbk.notification_cb         = notification_cb;
    g_sle_uart_ssapc_cbk.indication_cb           = indication_cb;
    ssapc_register_callbacks(&g_sle_uart_ssapc_cbk);
}

// 注册 SLE SSAP 客户端
static errcode_t sle_uuid_client_register(void)
{
    sle_uuid_t app_uuid = {0};
    osal_printk("[uuid client] ssapc_register_client \r\n");
    app_uuid.len = sizeof(g_sle_uuid_app_uuid);
    if(memcpy_s(app_uuid.uuid, app_uuid.len, g_sle_uuid_app_uuid, sizeof(g_sle_uuid_app_uuid)) != 0)
    {
        return ERRCODE_SLE_FAIL;
    }
    return ssapc_register_client(&app_uuid, &g_client_id);
}

/* device 通过 handle 向 host 发送数据：report */
errcode_t sle_uart_client_send_report_by_handle(const uint8_t *data, uint8_t len)
{
    ssapc_write_param_t param = {0};
    uint8_t receive_buf[0x100] = { 0 };
    param.handle = g_sle_uart_find_service_result.start_hdl;
    param.type = 0;
    param.data = receive_buf;
    param.data_len = len + 1;
    if(memcpy_s(param.data, param.data_len, data, len) != 0)
    {
        return ERRCODE_SLE_FAIL;
    }
    return ssapc_write_req(g_client_id,g_sle_uart_conn_id, &param);
}

// SSAP 客户端通知事件上报回调函数
void my_ssapc_notification_callback(uint8_t client_id, uint16_t conn_id,
                                        ssapc_handle_value_t *data, errcode_t status)
{
    (void)client_id;
    (void)conn_id;
    (void)status;
    data -> data[data -> data_len - 1] = '\0';
    osal_printk("server_send_data: %s\r\n",data -> data);     
}

// SSAP 客户端指示事件上报回调函数
void my_ssapc_indication_callback(uint8_t client_id, uint16_t conn_id,
                                        ssapc_handle_value_t *data, errcode_t status)
{
    (void)client_id;
    (void)conn_id;
    (void)data;
    (void)status;
}

// 执行客户端初始化
void sle_uart_client_init(void)
{
    uint8_t local_addr[SLE_ADDR_LEN] = { 0x13, 0x67,0x5c, 0x07, 0x00, 0x51 };
    sle_addr_t local_address;
    local_address.type = 0;
    memcpy_s(local_address.addr, SLE_ADDR_LEN, local_addr, SLE_ADDR_LEN);
    // 注册事件回调
    sle_uuid_client_register();
    sle_seek_cbk_register();
    sle_connect_cbk_register();
    sle_ssapc_cbk_register(my_ssapc_notification_callback, my_ssapc_indication_callback);
    // 使能 SLE 协议栈
    enable_sle();
    // 设置本地地址
	sle_set_local_addr(&local_address);
}

void SleTask(void * param)
{
   (void)param;
    osal_msleep(1000);
    sle_uart_client_init();
}

int sle_init(void)
{
    // 初始化 SLE
    osal_kthread_lock();
    osal_task * task = osal_kthread_create(SleTask, NULL, "SleTask3", 4096);
    if(task == NULL)
    {
        osal_printk("Failed to create thread!\r\n");
    }
    else
    {
        osal_printk("Thread created successfully.\r\n");
        osal_kthread_set_priority(task, OSAL_TASK_PRIORITY_HIGH);
    }
    osal_kthread_unlock();
    return task != NULL;
}

// SLE 发送数据
errcode_t sle_send_buf(uint8_t *buffer, uint8_t length)
{
    errcode_t ret = ERRCODE_SUCC;
    if(length > 0)
    {
        ret = sle_uart_client_send_report_by_handle(buffer, length);
    }
    return ret;
}
