/**
 * joystick.c - 摇杆功能封装
 * by Nixsawe <ziming_cool@126.com>
 * 摇杆控制功能计算及封装
 */

#include "joystick_def.h"

int32_t joystick_raw[4];
int32_t joystick_processed[4];

joystick_range_t joystick_ranges[4] = {
    { .low = 105, .mid = 2305, .high = 3560 },  // JOYSTICK_LEFT_X
    { .low = 103, .mid = 2260, .high = 3560 },  // JOYSTICK_LEFT_Y
    { .low = 139, .mid = 2364, .high = 3560 },  // JOYSTICK_RIGHT_X
    { .low = 130, .mid = 2520, .high = 3560 },  // JOYSTICK_RIGHT_Y
};

// 执行摇杆校准
// 校准完成后返回 1，校准超时失败返回 0
int joystick_calibrate(void)
{
    // TODO
    return 1;
}

// 根据 ADC 采样值 joystick_raw 进行输出结果的计算，填充回 joystick_processed
void joystick_process(void)
{
    // 区间
    for(int ch = 0; ch < 4; ch ++)
    {
        joystick_range_t * range = (joystick_range_t *)&joystick_ranges[ch];
        
        int32_t val = joystick_raw[ch];

        if(val >= range -> mid - 200 && val <= range -> mid + 200)
        {
            // 摇杆位于中间
            val = 0;
        }
        else if(val > range -> mid)
        {
            // 正半
            if(val < range -> high)
            {
                val = (val - range -> mid - 200) * 100 / (range -> high - range -> mid - 200);
            }
            else
            {
                val = 100;
            }
            if(val > 100) val = 100;
        }
        else
        {
            // 负半
            if(val > range -> low)
            {
                val = (val - range -> mid + 200) * 100 / (range -> mid - 200 - range -> low);
            }
            else
            {
                val = -100;
            }
            if(val < -100) val = -100;
        }

        joystick_processed[ch] = val;
    }
}
