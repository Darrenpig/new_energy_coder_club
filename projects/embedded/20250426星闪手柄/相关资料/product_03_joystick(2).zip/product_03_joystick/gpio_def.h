/**
 * gpio_def.h - GPIO 功能封装 (头文件)
 * by Nixsawe <ziming_cool@126.com>
 * 进行 GPIO 相关资源的初始化与控制功能封装
 */

#ifndef _GPIO_DEF_H_
#define _GPIO_DEF_H_

// 包含必备头文件
#include "pinctrl.h"
#include "gpio.h"

// 手柄引脚定义
#define LED_STATE   0   // GPIO_00 配网 LED 灯, GPIO 模式
#define KEY_MODE    1   // GPIO_01 MODE 按键, GPIO 模式
#define KEY_SLE     2   // GPIO_02 SLE 按键, GPIO 模式
#define LED_A       3   // GPIO_03 自定义 LED, GPIO 模式
#define KEY_LEFT    4   // GPIO_04 前左自定义按键, GPIO 模式
#define KEY_RIGHT   5   // GPIO_05 前右自定义按键, GPIO 模式
#define LED_B       6   // GPIO_06 自定义 LED, GPIO 模式
                        // GPIO_07 右摇杆 ADC X 方向, 复用 ADC0
                        // GPIO_08 左摇杆 ADC X 方向, 复用 ADC1
                        // GPIO_09 左摇杆 ADC Y 方向, 复用 ADC2
                        // GPIO_10 右摇杆 ADC Y 方向, 复用 ADC3
                        // GPIO_11
                        // GPIO_12
#define SW_LEFT     13  // GPIO_13 左摇杆 SW, GPIO 模式
#define SW_RIGHT    14  // GPIO_14 右摇杆 SW, GPIO 模式

// 函数原型
void gpio_init(void);

#endif /* _GPIO_DEF_H_ */

