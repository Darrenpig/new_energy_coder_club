/**
 * sle_def.h - SLE 功能封装 (头文件)
 * by Nixsawe <ziming_cool@126.com>
 * 进行 SLE 相关资源的初始化与控制功能封装
 */

#ifndef _SLE_DEF_H_
#define _SLE_DEF_H_

// 包含必备头文件
#include<osal_debug.h>
#include<common_def.h>
#include<soc_osal.h>
#include<sle_device_discovery.h>
#include<sle_connection_manager.h>
#include<sle_ssap_client.h>
#include<sle_errcode.h>
#include<string.h>
#include<common_def.h>
#include<errcode.h>

// 一些常量和全局变量定义
#define SLE_MTU_SIZE_DEFAULT        512
#define SLE_SEEK_INTERVAL_DEFAULT   100
#define SLE_SEEK_WINDOW_DEFAULT     100
#ifndef SLE_UART_SERVER_NAME
#define SLE_UART_SERVER_NAME        "sle_uart_server"
#endif
#define SLE_UART_CLIENT_LOG         "[sle uart client]"

extern uint8_t sle_connected;

// 函数原型
int sle_init(void);
void sle_uart_client_init(void);
// errcode_t sle_uart_client_send_report_by_handle(const uint8_t *data, uint8_t len);
errcode_t sle_send_buf(uint8_t *buffer, uint8_t length);

#endif /* _SLE_DEF_H_ */

